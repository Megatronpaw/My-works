﻿namespace TestingPlatform.Enums
{
    public enum TestType
    {
        Education = 1,
        Activity = 2,
        Other = 3
    }

}
